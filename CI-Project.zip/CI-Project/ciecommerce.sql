-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2025 at 06:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) UNSIGNED NOT NULL,
  `fk_product_id` int(11) UNSIGNED NOT NULL,
  `fk_user_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `fk_product_id`, `fk_user_id`, `qty`, `cost`, `created_at`, `updated_at`) VALUES
(3, 3, 2, 1, 50000.00, '2025-11-21 18:09:30', '2025-11-21 18:09:30'),
(4, 1, 1, 2, 10000.00, '2025-11-23 07:35:03', '2025-11-23 07:35:04');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) UNSIGNED NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_image` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `cat_image`, `created_at`, `updated_at`) VALUES
(1, 'Mobile', '', '2025-11-15 06:07:53', '2025-11-15 06:07:53'),
(2, 'Electronics', '', '2025-11-15 06:09:45', '2025-11-15 06:09:45'),
(3, 'Media', '', '2025-11-15 06:10:52', '2025-11-15 06:10:52');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(59, '2025-01-01-000000', 'App\\Database\\Migrations\\RegistrationTable', 'default', 'App', 1763186040, 1),
(60, '2025-01-01-000100', 'App\\Database\\Migrations\\Order', 'default', 'App', 1763186040, 1),
(61, '2025-01-01-000100', 'App\\Database\\Migrations\\Orderitems', 'default', 'App', 1763186040, 1),
(62, '20251010230049', 'App\\Database\\Migrations\\Category', 'default', 'App', 1763186040, 1),
(63, '20251010230058', 'App\\Database\\Migrations\\Product', 'default', 'App', 1763186040, 1),
(64, '20251110100033', 'App\\Database\\Migrations\\Cart', 'default', 'App', 1763186040, 1),
(65, '20251110100033', 'App\\Database\\Migrations\\CreateShippingAddressTable', 'default', 'App', 1763230486, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) UNSIGNED NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_qty` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `fk_orderid` int(11) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `order_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_date` datetime NOT NULL,
  `order_status` enum('pending','completed','canceled') NOT NULL DEFAULT 'pending',
  `fk_user_id` int(11) UNSIGNED NOT NULL,
  `order_type` varchar(255) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(5) UNSIGNED NOT NULL,
  `product_name` text DEFAULT NULL,
  `product_dsc` text DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `selling_price` decimal(10,2) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `fk_catid` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_dsc`, `qty`, `selling_price`, `image`, `created_at`, `updated_at`, `fk_catid`) VALUES
(1, 'Samsung M11', '<p>Best Feature with low price</p>', 1, 10000.00, '1763186953_c827b4e18493c03277a5.jpg', '2025-11-15 06:09:13', '2025-11-15 06:09:13', 1),
(2, 'Kids RC Cars', '<p>Buy Rc Car</p>', 1, 500.00, '1763187024_58d8d3a19cb68d182f73.webp', '2025-11-15 06:10:24', '2025-11-15 06:10:24', 2),
(3, 'Nothing Phone 1', '<p>Buy Now Pay Later</p>', 1, 50000.00, '1763187091_0ca478d2ad3b725957df.jpg', '2025-11-15 06:11:31', '2025-11-15 06:11:31', 3);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(5) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `email`, `mobile`, `password`, `created_at`, `updated_at`) VALUES
(1, 'ABDUL SALAM', 'abdulsalam786gaur@gmail.com', '9718138545', '$2y$10$cQC3orlmDgzOJmsVAl3bHON0jeH3/.b.OgcT6GNHsdm5qOHXyn9I.', '2025-11-15 06:04:32', '2025-11-15 06:04:32'),
(2, 'Izhaan', 'Ali@gmail.com', '8938958105', '$2y$10$v2y2JSNjJpapJ4NScct0I.pDFtA0sBmFzyYxk6S8zxwkC0vpLET.e', '2025-11-15 17:52:26', '2025-11-15 17:52:26');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_address`
--

CREATE TABLE `shipping_address` (
  `id` int(11) UNSIGNED NOT NULL,
  `fk_user_id` int(11) UNSIGNED NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `area` varchar(150) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `shipping_address`
--

INSERT INTO `shipping_address` (`id`, `fk_user_id`, `fname`, `lname`, `city`, `area`, `pincode`, `address`, `created_at`, `updated_at`) VALUES
(1, 1, 'ABDUL', 'SALAM', 'New Delhi', 'Saharanpur', '110025', 'Near Chand Masjid', '2025-11-24 17:58:05', '2025-11-24 17:58:05'),
(2, 1, 'ABS', 'SALAM', 'New Delhi', 'Saharanpur', '110025', 'Near Chand Masjid', '2025-11-24 18:01:34', '2025-11-24 18:01:34'),
(3, 1, 'javed', 'ali', 'New Delhi', 'Saharanpur', '110025', 'Near Chand Masjid', '2025-11-24 18:02:51', '2025-11-24 18:02:51'),
(4, 1, 'ABDUL', 'SALAM', 'New Delhi', 'Sector 4', '110025', 'Near Chand Masjid', '2025-11-24 18:03:27', '2025-11-24 18:03:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_fk_product_id_foreign` (`fk_product_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orderid` (`fk_orderid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`),
  ADD KEY `fk_user_id` (`fk_user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_fk_catid_foreign` (`fk_catid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `shipping_address`
--
ALTER TABLE `shipping_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`fk_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shipping_address`
--
ALTER TABLE `shipping_address`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_fk_product_id_foreign` FOREIGN KEY (`fk_product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD CONSTRAINT `orderitems_fk_orderid_foreign` FOREIGN KEY (`fk_orderid`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_fk_user_id_foreign` FOREIGN KEY (`fk_user_id`) REFERENCES `registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_fk_catid_foreign` FOREIGN KEY (`fk_catid`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shipping_address`
--
ALTER TABLE `shipping_address`
  ADD CONSTRAINT `shipping_address_fk_user_id_foreign` FOREIGN KEY (`fk_user_id`) REFERENCES `registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
